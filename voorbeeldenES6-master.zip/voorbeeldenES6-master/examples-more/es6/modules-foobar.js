// foobar.js
export var foo = 'foo';
export var bar = 'bar';

export class Person{
	constructor(){
		this.name = 'Peter Kassenaar'
	}
	getName(){
		return this.name;
	}
}
