# voorbeeldenES6
Codevoorbeelden behorende bij de training ECMAScript 2015 / ES6

## examples
In deze map staan de voorbeelden in de volgorde van het boek WebDevelopment Library - ES6/TypeScript

## examples-more
In deze map staan enkele andere voorbeelden: ouder en minder gesorteerd. Draai in deze folder `npm install` om dependencies te installeren. Er staat ook een voorbeeld in van het werken met browserify.
